# Phosphor Console — MUI theme + component library

A dark-only **NERV/MAGI tactical** Material UI (v7+) theme plus the paired
console component library. This tarball is a **TypeScript source** distribution
(no build step) — your app's bundler transpiles it, exactly like the source repo
does.

## Install

```bash
npm install ./phosphor-console-theme-0.1.0.tgz
# peers (if not already present):
npm install @mui/material @emotion/react @emotion/styled
# optional: @mui/icons-material @mui/x-data-grid
```

## Use

```tsx
import { ThemeProvider, CssBaseline } from '@mui/material';
import { theme } from 'phosphor-console-theme';
import { StatusLegend, SegmentedMeter } from 'phosphor-console-theme/components';

export function App() {
  return (
    <ThemeProvider theme={theme} defaultMode="dark">
      <CssBaseline />
      <StatusLegend items={[{ jp: '正常', en: 'NOMINAL', tone: 'mint' }]} />
      <SegmentedMeter />
    </ThemeProvider>
  );
}
```

Subpath exports:

| Import                                  | Contents                          |
| --------------------------------------- | --------------------------------- |
| `phosphor-console-theme`                | the theme (`theme`, default)      |
| `phosphor-console-theme/components`     | the console component library     |

## Bundler note (important)

Because this package ships `.ts`/`.tsx` source, your bundler must transpile it —
i.e. **don't exclude this package from TS handling**.

- **Vite** — add it to `optimizeDeps.exclude` or `ssr.noExternal` so it's
  processed by the app pipeline. Also `dedupe` React/MUI/emotion so there's a
  single copy (a second React copy breaks hooks once a Dialog/Modal mounts):

  ```ts
  resolve: {
    dedupe: ['react', 'react-dom', '@mui/material', '@emotion/react', '@emotion/styled'],
  }
  ```

- **Next.js** — add `transpilePackages: ['phosphor-console-theme']` in
  `next.config.js`.

## Tokens & customizing

Structural tokens live on `theme.nerv.*`; palette tokens on
`theme.palette.nerv.*` (CSS vars, reachable via `theme.vars.palette.nerv.*`).
Single `dark` scheme; `cssVariables` is on. See `theme/README.md` and
`components/README.md` inside the package for the full token + component catalog.
